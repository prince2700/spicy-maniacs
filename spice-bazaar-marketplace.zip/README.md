
# Spice Bazaar Marketplace Demo

This is an enhanced demo of Spice Bazaar with marketplace features:
- Multi-vendor listings
- Cart & checkout simulation
- Product detail modal with reviews
- Seller storefront demo
- Search and basic filters

## Quick start

```
npm install
npm start
```

Open http://localhost:3000
