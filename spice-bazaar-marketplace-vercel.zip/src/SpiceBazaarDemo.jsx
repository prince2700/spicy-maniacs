import React, { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import './styles.css';

const STORAGE_KEY = 'spice_bazaar_marketplace_v1';

function loadData() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) return JSON.parse(raw);
  const demo = seedData();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(demo));
  return demo;
}
function saveData(d){ localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); }

function seedData(){
  const lab = uuidv4();
  const s1 = uuidv4();
  const s2 = uuidv4();
  const p1 = uuidv4(), p2 = uuidv4(), p3 = uuidv4(), p4 = uuidv4();
  const b1 = uuidv4(), b2 = uuidv4(), b3 = uuidv4(), b4 = uuidv4();

  return {
    users: [
      { id: 'buyer-1', name: 'Global Importers', role:'buyer' },
      { id: s1, name: 'Kisan Spices Co-op', role:'seller' },
      { id: s2, name: 'HerbalExtractors Ltd', role:'seller' },
      { id: 'admin-1', name: 'Spice Bazaar Admin', role:'admin' },
      { id: lab, name: 'AgriTest Labs', role:'lab' }
    ],
    categories: [
      { id:'supplements', name:'Supplements' },
      { id:'nutraceuticals', name:'Nutraceuticals' },
      { id:'pharmaceuticals', name:'Pharmaceuticals' },
      { id:'food_processing', name:'Food Processing' }
    ],
    products: [
      { id:p1, name:'Turmeric Powder', category:'supplements', org_id:s1, price:2.5, desc:'Culinary & supplement grade', rating:4.2 },
      { id:p2, name:'Curcumin 95%', category:'nutraceuticals', org_id:s2, price:28.0, desc:'Standardized curcumin extract', rating:4.8 },
      { id:p3, name:'Capsaicin 10%', category:'pharmaceuticals', org_id:s2, price:120.0, desc:'Pharma grade capsaicin', rating:4.5 },
      { id:p4, name:'Black Pepper Oleoresin', category:'food_processing', org_id:s1, price:18.0, desc:'Oleoresin, piperine standardized', rating:4.1 }
    ],
    batches: [
      { id:b1, product_id:p1, lot:'TUR-001', qty:1200, unit:'kg' },
      { id:b2, product_id:p2, lot:'CUR95-001', qty:200, unit:'kg' },
      { id:b3, product_id:p3, lot:'CAP10-001', qty:50, unit:'kg' },
      { id:b4, product_id:p4, lot:'BPO-01', qty:500, unit:'kg' }
    ],
    coas: [],
    orders: [],
    reviews: [],
    cart: []
  };
}

/* Helpers */
function fmt(n){ return Number(n).toFixed(2); }

export default function SpiceBazaarDemo() {
  const [data, setData] = useState(()=> loadData());
  const [q, setQ] = useState('');
  const [selectedCat, setSelectedCat] = useState(data.categories[0].id);
  const [mode, setMode] = useState('market'); // market | seller | lab | admin
  const [preview, setPreview] = useState(null); // product detail
  const [cart, setCart] = useState(data.cart || []);
  const [sellerView, setSellerView] = useState(null);

  useEffect(()=> saveData({...data, cart}), [data, cart]);

  /* Search + filter */
  const products = data.products.filter(p => p.category === selectedCat && p.name.toLowerCase().includes(q.toLowerCase()));

  function addToCart(productId, qty=1){
    const prod = data.products.find(p=>p.id===productId);
    if(!prod) return;
    const existing = cart.find(c=>c.product_id===productId);
    if(existing){ setCart(cart.map(c=> c.product_id===productId ? {...c, qty:c.qty+qty} : c)); }
    else { setCart([{ id: uuidv4(), product_id: productId, qty }, ...cart]); }
  }

  function removeFromCart(itemId){ setCart(cart.filter(c=>c.id!==itemId)); }

  function openProduct(id){ setPreview(data.products.find(p=>p.id===id)); }

  function placeOrderMock(){ 
    if(cart.length===0) return alert('Cart empty');
    const order = { id: uuidv4(), items: cart, status:'escrowed', created_at: new Date().toISOString() };
    const newData = {...data, orders: [order, ...data.orders], cart: [], };
    setData(newData); setCart([]); alert('Order placed — funds held in escrow (demo)');
  }

  function viewSeller(sellerId){ setSellerView(data.users.find(u=>u.id===sellerId)); setMode('seller'); }

  function submitReview(productId, user, rating, text){
    const r = { id: uuidv4(), product_id: productId, user, rating, text };
    const nd = {...data, reviews: [r, ...data.reviews]};
    setData(nd); alert('Thanks for review (demo)');
  }

  const cartTotal = cart.reduce((s,c)=>{
    const p = data.products.find(x=>x.id===c.product_id);
    return s + (p ? p.price*c.qty : 0);
  },0);

  return (
    <div>
      <div className="header">
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <div style={{fontWeight:900, fontSize:20}}>Spice Bazaar</div>
          <div style={{background:'#fff', padding:'6px 10px', borderRadius:8, color:'#333'}}>Marketplace</div>
        </div>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <input placeholder="Search products, extracts, bioactives..." value={q} onChange={e=>setQ(e.target.value)} style={{padding:8, borderRadius:8, border:'none', width:360}} />
          <select value={selectedCat} onChange={e=>setSelectedCat(e.target.value)} style={{padding:8, borderRadius:8}}>
            {data.categories.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button onClick={()=>setMode('market')} style={{padding:'8px 12px', borderRadius:8}}>Marketplace</button>
          <button onClick={()=>{ setMode('admin'); setSellerView(null); }} style={{padding:'8px 12px', borderRadius:8}}>Admin</button>
          <div style={{background:'#fff', padding:'6px 8px', borderRadius:8}} onClick={()=>setPreview({openCart:true})}>Cart <span style={{marginLeft:8}} className="badge">{cart.length}</span></div>
        </div>
      </div>

      <div className="container">
        <div className="grid">
          <main>
            <div className="card">
              <h3 style={{marginTop:0}}>Products</h3>
              <div className="small">Showing {products.length} products in <strong>{data.categories.find(c=>c.id===selectedCat).name}</strong></div>

              {products.map(p => (
                <div key={p.id} className="product">
                  <div>
                    <h4>{p.name} <span className="small"> — {p.desc}</span></h4>
                    <div className="small">Price: ${fmt(p.price)} • Rating: <span className="rating">{p.rating}</span> • <span className="seller" onClick={()=>viewSeller(p.org_id)}>Seller: {data.users.find(u=>u.id===p.org_id).name}</span></div>
                  </div>
                  <div style={{display:'flex', gap:8, alignItems:'center'}}>
                    <button onClick={()=>openProduct(p.id)} style={{padding:'8px 10px'}}>View</button>
                    <button onClick={()=>addToCart(p.id,1)} style={{padding:'8px 10px', background:'#0ea5a4', color:'#fff', borderRadius:8}}>Add to cart</button>
                  </div>
                </div>
              ))}
            </div>

            <div style={{height:18}}></div>

            <div className="card">
              <h3 style={{marginTop:0}}>Orders (Demo)</h3>
              {data.orders.length===0 && <div className="small">No orders yet — place one from the cart.</div>}
              {data.orders.map(o=> (
                <div key={o.id} style={{padding:10, borderBottom:'1px solid #f0f0f0'}}>
                  <div><strong>Order {o.id.slice(0,8)}</strong> • {new Date(o.created_at).toLocaleString()}</div>
                  <div className="small">Status: {o.status} • Items: {o.items.length}</div>
                </div>
              ))}
            </div>
          </main>

          <aside>
            <div className="card">
              <h4 style={{marginTop:0}}>Cart</h4>
              {cart.length===0 && <div className="small">Cart is empty.</div>}
              {cart.map(item=>{
                const p = data.products.find(x=>x.id===item.product_id);
                return (
                  <div key={item.id} className="cart-item">
                    <div>
                      <div><strong>{p.name}</strong></div>
                      <div className="small">{item.qty} × ${fmt(p.price)}</div>
                    </div>
                    <div>
                      <div>${fmt(p.price*item.qty)}</div>
                      <div style={{marginTop:6}}><button onClick={()=>removeFromCart(item.id)} style={{background:'#fee', border:'1px solid #fbb', borderRadius:6, padding:'6px 8px'}}>Remove</button></div>
                    </div>
                  </div>
                )
              })}
              <div style={{paddingTop:8, borderTop:'1px solid #eee', marginTop:8}}>
                <div style={{display:'flex', justifyContent:'space-between'}}><div className="small">Total</div><div><strong>${fmt(cartTotal)}</strong></div></div>
                <div style={{marginTop:8, display:'flex', gap:8}}>
                  <button onClick={placeOrderMock} style={{flex:1, padding:'10px', background:'#FF8C94', color:'#fff', borderRadius:8}}>Place Order (Escrow)</button>
                  <button onClick={()=>alert('Checkout flow demo — integrate real PG')} style={{padding:'10px', borderRadius:8}}>Checkout</button>
                </div>
              </div>
            </div>

            <div style={{height:18}}></div>

            <div className="card">
              <h4 style={{marginTop:0}}>Top Rated</h4>
              {data.products.slice().sort((a,b)=>b.rating-a.rating).slice(0,3).map(p=> (
                <div key={p.id} style={{padding:8, borderBottom:'1px dashed #eee'}}>
                  <div><strong>{p.name}</strong></div>
                  <div className="small">Rating: <span className="rating">{p.rating}</span></div>
                </div>
              ))}
            </div>
          </aside>
        </div>

        {/* Seller storefront */}
        {sellerView && (
          <div style={{marginTop:18}}>
            <div className="card">
              <div style={{display:'flex', justifyContent:'space-between'}}>
                <div>
                  <h3 style={{margin:0}}>Seller: {sellerView.name}</h3>
                  <div className="small">Seller storefront demo — listings below</div>
                </div>
                <div style={{display:'flex', gap:8}}>
                  <button onClick={()=>{ setSellerView(null); setMode('market'); }}>Back to marketplace</button>
                </div>
              </div>

              <div style={{marginTop:12}}>
                {data.products.filter(p=>p.org_id===sellerView.id).map(p=> (
                  <div key={p.id} className="product">
                    <div>
                      <h4>{p.name}</h4>
                      <div className="small">{p.desc}</div>
                    </div>
                    <div style={{display:'flex', gap:8}}>
                      <button onClick={()=>openProduct(p.id)}>View</button>
                      <button onClick={()=>addToCart(p.id,1)} style={{background:'#0ea5a4', color:'#fff', padding:'8px 10px', borderRadius:6}}>Add</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Product preview modal & reviews */}
        {preview && preview.openCart && (
          <div className="modal" onClick={()=>setPreview(null)}>
            <div className="modal-content" onClick={e=>e.stopPropagation()}>
              <h3>Your cart</h3>
              {cart.length===0 && <div className="small">Cart empty</div>}
              {cart.map(c=>{
                const p = data.products.find(x=>x.id===c.product_id);
                return <div key={c.id} style={{display:'flex', justifyContent:'space-between', padding:8}}><div>{p.name} × {c.qty}</div><div>${fmt(p.price*c.qty)}</div></div>
              })}
              <div style={{marginTop:12}}><strong>Total: ${fmt(cartTotal)}</strong></div>
              <div style={{marginTop:12, display:'flex', gap:8}}>
                <button onClick={()=>{ setPreview(null); placeOrderMock(); }} style={{background:'#FF8C94', color:'#fff', padding:10, borderRadius:6}}>Place order (Escrow)</button>
                <button onClick={()=>setPreview(null)} style={{padding:10}}>Close</button>
              </div>
            </div>
          </div>
        )}

        {preview && preview.id && (
          <div className="modal" onClick={()=>setPreview(null)}>
            <div className="modal-content" onClick={e=>e.stopPropagation()}>
              <div style={{display:'flex', justifyContent:'space-between'}}>
                <div>
                  <h2 style={{margin:0}}>{preview.name}</h2>
                  <div className="small">{preview.desc}</div>
                  <div style={{marginTop:8}}>Price: <strong>${fmt(preview.price)}</strong> • Rating: <span className="rating">{preview.rating}</span></div>
                  <div style={{marginTop:12}}>
                    <button onClick={()=>addToCart(preview.id,1)} style={{padding:10, background:'#0ea5a4', color:'#fff', borderRadius:8}}>Add to cart</button>
                    <button onClick={()=>openProduct(preview.id)} style={{marginLeft:8}}>Open</button>
                  </div>
                </div>
                <div style={{width:260}}>
                  <div style={{fontWeight:700}}>Seller</div>
                  <div className="small">{data.users.find(u=>u.id===preview.org_id).name}</div>
                </div>
              </div>

              <hr style={{margin:'12px 0'}} />
              <h4>Reviews</h4>
              {data.reviews.filter(r=>r.product_id===preview.id).map(r=> (
                <div key={r.id} style={{padding:8, borderBottom:'1px dashed #eee'}}>
                  <div><strong>{r.user}</strong> • <span className="rating">{'★'.repeat(r.rating)}</span></div>
                  <div className="small">{r.text}</div>
                </div>
              ))}

              <div style={{marginTop:12}}>
                <h4>Write a review (demo)</h4>
                <ReviewForm productId={preview.id} onSubmit={(user, rating, text)=>{ submitReview(preview.id, user, rating, text); }} />
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  )
}

/* Simple review form */
function ReviewForm({ productId, onSubmit }){
  const [name, setName] = useState('Buyer');
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  return (
    <div style={{display:'flex', flexDirection:'column', gap:8}}>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" style={{padding:8, borderRadius:6}} />
      <select value={rating} onChange={e=>setRating(Number(e.target.value))} style={{padding:8, borderRadius:6}}>
        {[5,4,3,2,1].map(n=> <option key={n} value={n}>{n} stars</option>)}
      </select>
      <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Write a short review" style={{padding:8, borderRadius:6}} />
      <div style={{display:'flex', gap:8}}>
        <button onClick={()=>{ onSubmit(name, rating, text); setText(''); }} style={{padding:8, background:'#86A8E7', color:'#fff', borderRadius:6}}>Submit</button>
      </div>
    </div>
  )
}
