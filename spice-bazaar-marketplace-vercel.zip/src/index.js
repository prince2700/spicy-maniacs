import React from 'react';
import { createRoot } from 'react-dom/client';
import SpiceBazaarDemo from './SpiceBazaarDemo';
import './styles.css';

const root = createRoot(document.getElementById('root'));
root.render(<SpiceBazaarDemo />);
