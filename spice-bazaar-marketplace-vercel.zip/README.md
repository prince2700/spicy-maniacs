
Spice Bazaar Marketplace - Vercel-ready ZIP
------------------------------------------

Fixes applied for Vercel deployment:
- `dist/index.html` added which loads `bundle.js`.
- `webpack` outputs bundle.js into `dist/` (webpack.config.js configured).
- `vercel.json` sets outputDirectory to `dist` so Vercel will serve dist/ as the site root.
- Build command (on Vercel) should be: `npm run build` (Vercel autodetects from package.json).

How to deploy on Vercel (drag & drop):
1. Go to https://vercel.com/new
2. Choose "Upload Project" and drag this ZIP.
3. Vercel will install dependencies and run `npm run build` then serve `dist/`.
4. If the site 404s, check the Vercel project's Build & Output settings: Build Command = `npm run build`, Output Directory = `dist`.

Local dev:
1. unzip
2. npm install
3. npm start
